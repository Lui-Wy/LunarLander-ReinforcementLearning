# pygame-script
# pygbag: width=800, height=640, scale=dynamic
import asyncio
import os
import numpy as np
import pygame

# Absolute Original-Imports aus deinem Projekt
from game_logic import GameState, Lander, Meteor, MAX_FUEL, WORLD_WIDTH, WORLD_HEIGHT, METEOR_MAX_RADIUS, spawn_meteor
from rendering import draw_screen

# Globale Konstanten für die Physik und das UI-Layout
HEADER_HEIGHT = 45
FPS = 60
PHYSICS_FPS = 60
PHYSICS_DT = 1.0 / PHYSICS_FPS
MAX_FRAME_TIME = 0.25
VELOCITY_NORM = 300.0

# Farben
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREY = (50, 50, 50)
CYAN = (0, 210, 255)
ORANGE = (255, 140, 0)


class NumPyDQN:
    def __init__(self):
        self.w0 = self._safe_load("net_0_weight.npy", (64, 14))
        self.b0 = self._safe_load("net_0_bias.npy", (64,))
        self.w2 = self._safe_load("net_2_weight.npy", (64, 64))
        self.b2 = self._safe_load("net_2_bias.npy", (64,))
        self.w4 = self._safe_load("net_4_weight.npy", (4, 64))
        self.b4 = self._safe_load("net_4_bias.npy", (4,))

    def _safe_load(self, filename, fallback_shape):
        if os.path.exists(filename):
            try:
                return np.load(filename)
            except Exception:
                pass
        return np.random.randn(*fallback_shape).astype(np.float32) * 0.1

    def relu(self, x):
        return np.maximum(0, x)

    def forward(self, x):
        x = self.relu(np.dot(self.w0, x) + self.b0)
        x = self.relu(np.dot(self.w2, x) + self.b2)
        return np.dot(self.w4, x) + self.b4


def get_observation(game_state: GameState) -> np.ndarray:
    lander = game_state.lander
    meteor = game_state.meteor
    pad_center_x = (game_state.pad_x_start + game_state.pad_x_end) / 2
    angle_norm = ((lander.angle + 180) % 360 - 180) / 180

    return np.array([
        lander.x / WORLD_WIDTH,
        lander.y / WORLD_HEIGHT,
        lander.vx / VELOCITY_NORM,
        lander.vy / VELOCITY_NORM,
        angle_norm,
        lander.fuel / MAX_FUEL,
        pad_center_x / WORLD_WIDTH,
        (lander.x - pad_center_x) / WORLD_WIDTH,
        meteor.x / WORLD_WIDTH,
        meteor.y / WORLD_HEIGHT,
        meteor.vx / VELOCITY_NORM,
        meteor.vy / VELOCITY_NORM,
        meteor.radius / METEOR_MAX_RADIUS
    ], dtype=np.float32)


def get_ai_action(model: NumPyDQN, game_state: GameState) -> int:
    observation = get_observation(game_state)
    q_values = model.forward(observation)
    return int(np.argmax(q_values))


def is_round_over(game_state: GameState) -> bool:
    lander = game_state.lander
    return lander.has_landed or not lander.is_alive


def reset_round(ai_state: GameState, human_state: GameState) -> None:
    ai_state.randomize_pad()
    pad_x_start = ai_state.pad_x_start
    pad_x_end = ai_state.pad_x_end

    meteor_template = spawn_meteor()

    for state in (ai_state, human_state):
        state.pad_x_start = pad_x_start
        state.pad_x_end = pad_x_end
        state.lander = Lander(WORLD_WIDTH // 2, 100)
        state.flight_time = 0.0
        state.meteor = Meteor(
            meteor_template.x,
            meteor_template.y,
            meteor_template.vx,
            meteor_template.vy,
            meteor_template.radius
        )


def sync_meteor_respawn(ai_state: GameState, human_state: GameState, last_meteor_id: int) -> int:
    if id(ai_state.meteor) != last_meteor_id:
        human_state.meteor = Meteor(
            ai_state.meteor.x,
            ai_state.meteor.y,
            ai_state.meteor.vx,
            ai_state.meteor.vy,
            ai_state.meteor.radius
        )
        return id(ai_state.meteor)
    return last_meteor_id


def draw_header(screen: pygame.Surface, font: pygame.font.Font, width: int, round_over: bool) -> None:
    # Header-Hintergrund zeichnen
    pygame.draw.rect(screen, GREY, (0, 0, width, HEADER_HEIGHT))

    half_w = width // 2

    if round_over:
        # Zentraler auffälliger Text bei Rundenende
        msg = font.render("RUNDENENDE - Hier tippen / 'R' drücken", True, WHITE)
        screen.blit(msg, msg.get_rect(center=(half_w, HEADER_HEIGHT // 2)))
    else:
        # Standard-Beschriftung im Spielbetrieb
        ai_label = font.render("KI-AGENT (LINKS)", True, CYAN)
        human_label = font.render("SPIELER (RECHTS)", True, ORANGE)
        
        screen.blit(ai_label, ai_label.get_rect(center=(half_w // 2, HEADER_HEIGHT // 2)))
        screen.blit(human_label, human_label.get_rect(center=(half_w + half_w // 2, HEADER_HEIGHT // 2)))

    # Trennlinie in der Mitte des Headers
    pygame.draw.line(screen, WHITE, (half_w, 0), (half_w, HEADER_HEIGHT), 2)


async def main():
    pygame.init()

    # Bildschirm dynamisch initialisieren (nutzt pygbag scale=dynamic auf Mobilgeräten)
    info = pygame.display.Info()
    screen_width = info.current_w if info.current_w > 0 else 800
    screen_height = info.current_h if info.current_h > 0 else 640
    
    screen = pygame.display.set_mode((screen_width, screen_height), pygame.RESIZABLE)
    pygame.display.set_caption("Lunar Lander: AI vs Human")

    clock = pygame.time.Clock()
    
    # Skalierende Schriftgröße basierend auf der aktuellen Fensterbreite
    font = pygame.font.Font(None, int(screen_width * 0.003))
    header_font = pygame.font.Font(None,  int(screen_width * 0.001))

    q_net = NumPyDQN()

    ai_state = GameState()
    human_state = GameState()
    reset_round(ai_state, human_state)
    last_meteor_id = id(ai_state.meteor)

    accumulator = 0.0
    ai_action = 0

    running = True
    while running:
        # Dynamische Fenstergröße bei jedem Frame neu berechnen (falls gedreht oder skaliert wird)
        current_w, current_h = screen.get_size()
        
        # Abmessungen für die zwei Spielhälften
        internal_width = current_w // 2
        internal_height = current_h - HEADER_HEIGHT

        frame_time = clock.tick(FPS) / 1000.0
        frame_time = min(frame_time, MAX_FRAME_TIME)
        accumulator += frame_time

        # Event-Handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.VIDEORESIZE:
                # Fenstergröße wurde (z.B. am PC) live geändert
                screen = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)
                font_size = max(16, int(event.w * 0.03))
                font = pygame.font.Font(None, font_size)
                header_font = pygame.font.Font(None, max(18, int(font_size * 1.1)))

        keys = pygame.key.get_pressed()
        round_over = is_round_over(ai_state) and is_round_over(human_state)
        
        # Standard-Tastaturbelegung (PC)
        human_main_thrust = keys[pygame.K_UP] or keys[pygame.K_SPACE] or keys[pygame.K_w]
        human_rotate_left = keys[pygame.K_LEFT] or keys[pygame.K_a]
        human_rotate_right = keys[pygame.K_RIGHT] or keys[pygame.K_d]
        
        # Dynamische Touch-/Maussteuerung (Handy & PC)
        if pygame.mouse.get_pressed()[0]:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            
            # Klick/Touch im Header führt zum Reset, wenn die Runde vorbei ist
            if round_over and mouse_y <= HEADER_HEIGHT:
                reset_round(ai_state, human_state)
                last_meteor_id = id(ai_state.meteor)
                round_over = False
            
            # Touch-Zonen auf der rechten Bildschirmhälfte (Mensch-Bereich)
            elif mouse_x > internal_width and mouse_y > HEADER_HEIGHT:
                relative_x = mouse_x - internal_width
                zone_width = internal_width // 3
                
                if relative_x < zone_width:
                    human_rotate_left = True
                elif relative_x > zone_width * 2:
                    human_rotate_right = True
                else:
                    human_main_thrust = True

        # Manueller Reset über Tastatur (PC)
        if keys[pygame.K_r] and round_over:
            reset_round(ai_state, human_state)
            last_meteor_id = id(ai_state.meteor)
            round_over = False

        # KI Input berechnen
        if not is_round_over(ai_state):
            ai_action = get_ai_action(q_net, ai_state)

        ai_state.set_inputs(
            main_thrust=ai_action == 1,
            rotate_right=ai_action == 2,
            rotate_left=ai_action == 3
        )

        # Mensch Input setzen
        human_state.set_inputs(
            main_thrust=human_main_thrust,
            rotate_right=human_rotate_right,
            rotate_left=human_rotate_left
        )

        # Physik-Update (Fixed Timestep)
        while accumulator >= PHYSICS_DT:
            if not round_over:
                ai_state.update(PHYSICS_DT)
                human_state.update(PHYSICS_DT)
                last_meteor_id = sync_meteor_respawn(ai_state, human_state, last_meteor_id)
            accumulator -= PHYSICS_DT

        #--- RENDERING-PROZESS ---
        
        # Sicherheits-Check: Nur zeichnen, wenn das Fenster eine sichtbare Fläche hat
        if internal_width > 10 and internal_height > 10:
            
            # Erzeuge dynamische Subsurfaces für die exakten Fensterhälften.
            # Jedes Subsurface spiegelt genau die Region auf dem Hauptbildschirm wider.
            ai_subsurface = screen.subsurface((0, HEADER_HEIGHT, internal_width, internal_height))
            human_subsurface = screen.subsurface((internal_width, HEADER_HEIGHT, internal_width, internal_height))
            
            # Rufe dein originales Rendering auf. Deine Funktionen nutzen intern `get_viewport`,
            # welches sich nun vollautomatisch an die dynamischen Maße der Subsurfaces anpasst!
            draw_screen(ai_subsurface, font, header_font, ai_state)
            draw_screen(human_subsurface, font, header_font, human_state)
        
        # Header und Trennlinien über das Geschehen legen
        draw_header(screen, header_font, current_w, round_over)
        pygame.draw.line(screen, WHITE, (internal_width, HEADER_HEIGHT), (internal_width, current_h), 2)

        # Da deine draw_screen Funktionen bereits intern ein display.flip() ausführen,
        # sorgt dieses finale flip() dafür, dass auch unser frisch gezeichneter Header sichtbar wird.
        pygame.display.flip()
        
        # Wichtig für den Asynchronen Web-Loop (Pygbag)
        await asyncio.sleep(0)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())