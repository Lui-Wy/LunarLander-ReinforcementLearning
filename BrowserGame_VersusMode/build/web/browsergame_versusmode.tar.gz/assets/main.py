# pygame-script
# pygbag: width=800, height=480, scale=dynamic, orientation=landscape
import asyncio
import os
import numpy as np
import pygame

# Die Logik- und Grafik-Imports aus deinen Unterordnern belassen wir exakt so
from game_logic import GameState, Lander, Meteor, MAX_FUEL, WORLD_WIDTH, WORLD_HEIGHT, METEOR_MAX_RADIUS, spawn_meteor
from rendering import draw_screen

# Globale Konfigurationen - angepasst für Smartphone-Querformat (800x480 ist der mobile Goldstandard)
HEADER_HEIGHT = 40
INTERNAL_WIDTH = 400
INTERNAL_HEIGHT = 440  # Ergibt zusammen mit Header 480 Pixel Höhe

SCREEN_WIDTH = INTERNAL_WIDTH * 2
SCREEN_HEIGHT = INTERNAL_HEIGHT + HEADER_HEIGHT
FPS = 60

PHYSICS_FPS = 60
PHYSICS_DT = 1.0 / PHYSICS_FPS
MAX_FRAME_TIME = 0.25
VELOCITY_NORM = 300.0

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREY = (60, 60, 60)
CYAN = (0, 200, 255)
ORANGE = (255, 165, 0)


# --- REINES NUMPY GEHIRN FÜR DEN BROWSER ---
class NumPyDQN:
    def __init__(self):
        self.w0 = self._safe_load("net_0_weight.npy", (64, 14))
        self.b0 = self._safe_load("net_0_bias.npy", (64,))
        self.w2 = self._safe_load("net_2_weight.npy", (64, 64))
        self.b2 = self._safe_load("net_2_bias.npy", (64,))
        self.w4 = self._safe_load("net_4_weight.npy", (4, 64))
        self.b4 = self._safe_load("net_4_bias.npy", (4,))

    def _safe_load(self, filename, fallback_shape):
        if os.path.exists(filename):
            try:
                return np.load(filename)
            except:
                pass
        return np.random.randn(*fallback_shape).astype(np.float32) * 0.1

    def relu(self, x):
        return np.maximum(0, x)

    def forward(self, x):
        x = self.relu(np.dot(self.w0, x) + self.b0)
        x = self.relu(np.dot(self.w2, x) + self.b2)
        return np.dot(self.w4, x) + self.b4


def get_observation(game_state: GameState) -> np.ndarray:
    lander = game_state.lander
    meteor = game_state.meteor
    pad_center_x = (game_state.pad_x_start + game_state.pad_x_end) / 2
    angle_norm = ((lander.angle + 180) % 360 - 180) / 180

    return np.array([
        lander.x / WORLD_WIDTH,
        lander.y / WORLD_HEIGHT,
        lander.vx / VELOCITY_NORM,
        lander.vy / VELOCITY_NORM,
        angle_norm,
        lander.fuel / MAX_FUEL,
        pad_center_x / WORLD_WIDTH,
        (lander.x - pad_center_x) / WORLD_WIDTH,
        meteor.x / WORLD_WIDTH,
        meteor.y / WORLD_HEIGHT,
        meteor.vx / VELOCITY_NORM,
        meteor.vy / VELOCITY_NORM,
        meteor.radius / METEOR_MAX_RADIUS
    ], dtype=np.float32)


def get_ai_action(model: NumPyDQN, game_state: GameState) -> int:
    observation = get_observation(game_state)
    q_values = model.forward(observation)
    return int(np.argmax(q_values))


def is_round_over(game_state: GameState) -> bool:
    lander = game_state.lander
    return lander.has_landed or not lander.is_alive


def reset_round(ai_state: GameState, human_state: GameState) -> None:
    ai_state.randomize_pad()
    pad_x_start = ai_state.pad_x_start
    pad_x_end = ai_state.pad_x_end

    meteor_template = spawn_meteor()

    for state in (ai_state, human_state):
        state.pad_x_start = pad_x_start
        state.pad_x_end = pad_x_end
        state.lander = Lander(WORLD_WIDTH // 2, 100)
        state.flight_time = 0.0
        state.meteor = Meteor(
            meteor_template.x,
            meteor_template.y,
            meteor_template.vx,
            meteor_template.vy,
            meteor_template.radius
        )


def sync_meteor_respawn(ai_state: GameState, human_state: GameState, last_meteor_id: int) -> int:
    if id(ai_state.meteor) != last_meteor_id:
        human_state.meteor = Meteor(
            ai_state.meteor.x,
            ai_state.meteor.y,
            ai_state.meteor.vx,
            ai_state.meteor.vy,
            ai_state.meteor.radius
        )
        return id(ai_state.meteor)
    return last_meteor_id


def draw_header(screen: pygame.Surface, font: pygame.font.Font, left_x: int, right_x: int, width: int) -> None:
    pygame.draw.rect(screen, GREY, (0, 0, width, HEADER_HEIGHT))

    ai_label = font.render("KI", True, CYAN)
    human_label = font.render("MENSCH", True, ORANGE)

    screen.blit(ai_label, ai_label.get_rect(center=(left_x, HEADER_HEIGHT // 2)))
    screen.blit(human_label, human_label.get_rect(center=(right_x, HEADER_HEIGHT // 2)))

    pygame.draw.line(screen, WHITE, (width // 2, 0), (width // 2, HEADER_HEIGHT), 2)


async def main():
    pygame.init()

    # Nativer Screen im Querformat
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Lunar Lander - AI vs Human")

    clock = pygame.time.Clock()
    
    # Kritisches Pygbag-Fixing: Keine SysFont auf Mobilgeräten nutzen!
    font = pygame.font.Font(None, 24)
    header_font = pygame.font.Font(None, 28)

    q_net = NumPyDQN()

    ai_state = GameState()
    human_state = GameState()
    reset_round(ai_state, human_state)
    last_meteor_id = id(ai_state.meteor)

    accumulator = 0.0
    ai_action = 0

    # Oberflächen für das originale Split-Screen-Design
    left_surface = pygame.Surface((INTERNAL_WIDTH, INTERNAL_HEIGHT))
    right_surface = pygame.Surface((INTERNAL_WIDTH, INTERNAL_HEIGHT))

    running = True
    while running:
        frame_time = clock.tick(FPS) / 1000.0
        frame_time = min(frame_time, MAX_FRAME_TIME)
        accumulator += frame_time

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # PC-Eingaben (bleiben als Backup aktiv)
        keys = pygame.key.get_pressed()
        round_over = is_round_over(ai_state) and is_round_over(human_state)
        
        human_main_thrust = keys[pygame.K_UP] or keys[pygame.K_SPACE]
        human_rotate_left = keys[pygame.K_LEFT]
        human_rotate_right = keys[pygame.K_RIGHT]
        
        # --- ERWEITERTE TOUCH-STEUERUNG FÜR SMARTPHONES ---
        if pygame.mouse.get_pressed()[0]:
            virtual_x, virtual_y = pygame.mouse.get_pos()
            
            # Reset über Touch im Header
            if round_over and virtual_y <= HEADER_HEIGHT:
                reset_round(ai_state, human_state)
                last_meteor_id = id(ai_state.meteor)
                round_over = False
            
            # Touch-Steuerung auf der rechten Bildschirmhälfte (Mensch-Spielfeld)
            elif virtual_x > INTERNAL_WIDTH and virtual_y > HEADER_HEIGHT:
                relative_x = virtual_x - INTERNAL_WIDTH
                zone_width = INTERNAL_WIDTH // 3
                
                # Teilt die rechte Bildschirmhälfte in 3 unsichtbare Touch-Zonen
                if relative_x < zone_width:
                    human_rotate_left = True    # Linkes Drittel: Links drehen
                elif relative_x > zone_width * 2:
                    human_rotate_right = True   # Rechtes Drittel: Rechts drehen
                else:
                    human_main_thrust = True    # Mittleres Drittel: Schub

        if keys[pygame.K_r] and round_over:
            reset_round(ai_state, human_state)
            last_meteor_id = id(ai_state.meteor)
            round_over = False

        if not is_round_over(ai_state):
            ai_action = get_ai_action(q_net, ai_state)

        ai_state.set_inputs(
            main_thrust=ai_action == 1,
            rotate_right=ai_action == 2,
            rotate_left=ai_action == 3
        )

        human_state.set_inputs(
            main_thrust=human_main_thrust,
            rotate_right=human_rotate_right,
            rotate_left=human_rotate_left
        )

        while accumulator >= PHYSICS_DT:
            if not round_over:
                ai_state.update(PHYSICS_DT)
                human_state.update(PHYSICS_DT)
                last_meteor_id = sync_meteor_respawn(ai_state, human_state, last_meteor_id)
            accumulator -= PHYSICS_DT

        # 1. Originales Rendern auf die getrennten Oberflächen
        left_surface.fill(BLACK)
        right_surface.fill(BLACK)
        draw_screen(left_surface, font, ai_state)
        draw_screen(right_surface, font, human_state)

        # 2. Zusammenfügen auf dem Hauptbildschirm
        screen.fill(BLACK)
        screen.blit(left_surface, (0, HEADER_HEIGHT))
        screen.blit(right_surface, (INTERNAL_WIDTH, HEADER_HEIGHT))
        
        # Trennlinien zeichnen
        pygame.draw.line(screen, WHITE, (INTERNAL_WIDTH, HEADER_HEIGHT), (INTERNAL_WIDTH, SCREEN_HEIGHT), 2)
        draw_header(screen, header_font, INTERNAL_WIDTH // 2, INTERNAL_WIDTH + (INTERNAL_WIDTH // 2), SCREEN_WIDTH)

        if round_over:
            message = header_font.render("Fertig! Tippe oben zum Neustarten", True, WHITE)
            screen.blit(message, message.get_rect(center=(SCREEN_WIDTH // 2, HEADER_HEIGHT // 2)))

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())